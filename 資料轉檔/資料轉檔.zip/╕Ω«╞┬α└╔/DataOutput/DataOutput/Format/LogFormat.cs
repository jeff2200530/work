﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataOutput.Format
{
    public class LogFormat
    {
        public string content = null;
        public string path = null;

    }
}
