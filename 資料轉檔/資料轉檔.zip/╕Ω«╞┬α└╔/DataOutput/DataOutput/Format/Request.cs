﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataOutput.Format
{
    public class Request
    {
        public FileInfo[] file { get; set; }
        public string table { get; set; }


    }
}
