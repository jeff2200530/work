﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataInput.Format
{
    public class FormFormat
    {
        public string processName { get; set; }
        public string column { get; set; }
        public string function { get; set; }
        public string startDate { get; set; }
        public string endDate { get; set; }
    }
}
